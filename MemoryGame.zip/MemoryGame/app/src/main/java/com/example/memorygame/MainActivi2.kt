package com.example.memorygame

import db.juegodememoria.DatabaseHandler
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale
import android.content.ContentValues
import org.w3c.dom.Text


class MainActivi2 : AppCompatActivity() {

    private lateinit var gridLayout: GridLayout
    private val imageViews = mutableListOf<ImageView>()
    private var score = 0
    private var selectedCard: ImageView? = null
    private var selectedImageRes: Int? = null
    private lateinit var timer: CountDownTimer
    private var timeLeftInMillis: Long = 120000



    private val imageResources = listOf(
        R.drawable.image1, R.drawable.image2, R.drawable.image3, R.drawable.image4,
        R.drawable.image5, R.drawable.image6, R.drawable.image7, R.drawable.image8
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        // Obtén el nombre del jugador y el último puntaje del intent
        val playerName = intent.getStringExtra("PLAYER_NAME")
        val lastScore = intent.getIntExtra("LAST_SCORE", 0)

        // Mostrar el nombre del jugador y el último puntaje en la cabecera
        val playerNameTextView = findViewById<TextView>(R.id.tvPlayerName)
        playerNameTextView.text = "Player: $playerName - Last Score: $lastScore"


        gridLayout = findViewById(R.id.gridLayout)
        setupGameBoard()

        val btnReset = findViewById<Button>(R.id.btnReset)
        btnReset.setOnClickListener {
            resetGame()
        }

        val btnExit = findViewById<Button>(R.id.btnExit)
        btnExit.setOnClickListener {
            finish()
        }


        startTimer()
    }

    private fun setupGameBoard() {
        // Eliminar todas las vistas existentes del GridLayout
        gridLayout.removeAllViews()

        val images = imageResources.shuffled().take(8) + imageResources.shuffled().take(8)
        images.shuffled().forEach { imageRes ->
            val imageView = ImageView(this)
            imageView.layoutParams = GridLayout.LayoutParams().apply {
                height = 220 // o cualquier tamaño que desees
                width = 220
                rightMargin = 8
                topMargin = 8
                bottomMargin = 8
                leftMargin = 8
            }
            imageView.setBackgroundResource(R.drawable.imagen9)
            imageView.setOnClickListener {
                onCardClicked(imageView, imageRes)
            }
            gridLayout.addView(imageView)
            imageViews.add(imageView)
        }
    }

    private fun onCardClicked(imageView: ImageView, imageRes: Int) {
        imageView.setImageResource(imageRes)

        if (selectedCard == null) {
            selectedCard = imageView
            selectedImageRes = imageRes
        } else {
            if (selectedImageRes == imageRes && selectedCard != imageView) {
                // Coincidencia encontrada
                playMatchSound()
                score += 10
                updateScoreDisplay()
                selectedCard!!.isEnabled = false
                imageView.isEnabled = false
                selectedCard = null
                selectedImageRes = null

                // Verificar si todas las cartas han sido emparejadas
                if (allCardsMatched()) {
                    onGameWon()
                }
            } else {
                Handler(Looper.getMainLooper()).postDelayed({
                    imageView.setImageResource(R.drawable.imagen9)
                    selectedCard?.setImageResource(R.drawable.imagen9)
                    selectedCard = null
                    selectedImageRes = null
                    score -= 5
                    updateScoreDisplay()
                }, 1000)
            }
        }
    }

    private fun allCardsMatched(): Boolean {
        return imageViews.none { it.isEnabled }
    }

    private fun onGameWon() {
        timer.cancel()
        Toast.makeText(this, "Congratulations! You have won! Your score is: $score", Toast.LENGTH_LONG).show()

        // Obtener el nombre del jugador
        val playerName = intent.getStringExtra("PLAYER_NAME")

        // Actualizar el último puntaje del jugador en la base de datos
        updatePlayerScore(playerName, score)

        // Puedes agregar cualquier lógica adicional que desees cuando el jugador gane
    }
    private fun updatePlayerScore(playerName: String?, newScore: Int) {
        playerName?.let {
            val databaseHandler = DatabaseHandler(this)
            val currentScore = databaseHandler.getLastScore(playerName)

            // Actualizar el puntaje solo si el nuevo puntaje es mayor que el anterior
            if (newScore > currentScore) {
                val db = databaseHandler.writableDatabase
                val values = ContentValues().apply {
                    put(DatabaseHandler.KEY_LAST_SCORE, newScore)
                }

                db.update(
                    DatabaseHandler.TABLE_NAME,
                    values,
                    "${DatabaseHandler.KEY_NAME} = ?",
                    arrayOf(playerName)
                )

                db.close()
            }
        }
    }

    private fun playMatchSound() {
        // Aquí debes implementar la reproducción del sonido de coincidencia
    }

    private fun resetGame() {
        // Restablecer el juego a su estado inicial
        score = 0
        updateScoreDisplay()
        selectedCard = null
        selectedImageRes = null
        imageViews.forEach {
            it.setImageResource(R.drawable.imagen9)
            it.isEnabled = true
        }
        timer.cancel()
        timeLeftInMillis = 120000
        startTimer()
    }

    private fun startTimer() {
        timer = object : CountDownTimer(timeLeftInMillis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timeLeftInMillis = millisUntilFinished
                updateCountDownText()
            }

            override fun onFinish() {
                onGameOver()
            }
        }.start()
    }

    private fun updateCountDownText() {
        val minutes = (timeLeftInMillis / 1000) / 60
        val seconds = (timeLeftInMillis / 1000) % 60
        val timeFormatted = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
        findViewById<TextView>(R.id.tvTimer).text = timeFormatted
    }

    private fun updateScoreDisplay() {
        findViewById<TextView>(R.id.tvScore).text = "Score: $score"
    }

    private fun onGameOver() {
        imageViews.forEach { it.isEnabled = false }
        Toast.makeText(this, "Game Over! Your score is: $score", Toast.LENGTH_LONG).show()

        // Detener el temporizador
        timer.cancel()

        // Guardar la puntuación en la base de datos si es necesario


        // Puedes agregar cualquier otra lógica que necesites después de que el juego haya terminado
    }


}
