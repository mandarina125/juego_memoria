package database

object PlayerContract {
    const val DATABASE_NAME = "players.db"
    const val DATABASE_VERSION = 1

    object PlayerEntry {
        const val TABLE_NAME = "player"
        const val COLUMN_NAME = "name"
        const val COLUMN_SCORE = "score"
    }
}
